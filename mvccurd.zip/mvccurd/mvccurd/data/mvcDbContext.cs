﻿using Microsoft.EntityFrameworkCore;
using mvccurd.Models;
using mvccurd.Models.domain;

namespace mvccurd.data
{
    public class mvcDbContext : DbContext
    {
        public mvcDbContext(DbContextOptions options) : base(options)
        {
        }
        public DbSet<employee> employees { get; set; }
    }
}
