﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using mvccurd.data;
using mvccurd.Models;
using mvccurd.Models.domain;
using System.ComponentModel.DataAnnotations;
using System.Reflection.Metadata.Ecma335;

namespace mvccurd.Controllers
{
    public class employees : Controller
    {
        private readonly mvcDbContext mvcDbContext;

        public employees(mvcDbContext mvcDbContext)
        {
            this.mvcDbContext = mvcDbContext;
        }
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var employees = await mvcDbContext.employees.ToListAsync();
            return View(employees);
        }
        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Add(Addemployees addemployeesRequest)
        {
            var employee = new employee()
            {
                Id = Guid.NewGuid(),
                Name = addemployeesRequest.Name,
                email = addemployeesRequest.email,
                salary = addemployeesRequest.salary,
                DateOfBirth = addemployeesRequest.DateOfBirth,
                department = addemployeesRequest.department,
            };
            await mvcDbContext.employees.AddAsync(employee);
            await mvcDbContext.SaveChangesAsync();
            return View("Index");
        }
        [HttpGet]
        public async Task<IActionResult> View(Guid Id)
        {
            var employee =await mvcDbContext.employees.FirstOrDefaultAsync(x => x.Id == Id); 
            if (employee != null)
            {
                var viewModel = new updateemployee()
                {
                    Id = employee.Id,
                    Name = employee.Name,
                    email = employee.email,
                    salary = employee.salary,
                    DateOfBirth = employee.DateOfBirth,
                    department = employee.department,

                };
                return await Task.Run(() => View("View", viewModel)); 
               
            }
            return RedirectToAction("Index");
        }
        [HttpPost]
        public async Task<IActionResult> View(updateemployee model)
        {
            var employee = await mvcDbContext.employees.FindAsync(model.Id);
            if(employee != null)
            {
                employee.Name = model.Name;
                employee.email=model.email;
                employee.salary = model.salary;
                 employee.DateOfBirth = model.DateOfBirth;
                employee.department = model.department;

                await mvcDbContext.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return RedirectToAction("Index");
        }
        [HttpPost]
        public async Task<IActionResult> Delete(updateemployee model)
        {
            var employee = await mvcDbContext.employees.FindAsync(model.Id);
            if(employee != null)
            {
                mvcDbContext.employees.Remove(employee);
                await mvcDbContext.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return RedirectToAction("Index");
        }
    }
}
