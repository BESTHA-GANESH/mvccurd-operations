﻿namespace mvccurd.Models.domain
{
    public class employee
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string email { get; set; }
        public long salary { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string department { get; set; }
    }
}
