﻿namespace mvccurd.Models
{
    public class Addemployees
    {
        public string Name { get; set; }
        public string email { get; set; }
        public long salary { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string department { get; set; }
    }
}
